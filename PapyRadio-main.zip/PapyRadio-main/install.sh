#!/bin/bash

echo "Installing PapyRadio dependencies"
sudo apt-get update
# Install the required packages via apt-get
sudo apt-get -y install

#required to end the plugin install
echo "plugininstallend"
